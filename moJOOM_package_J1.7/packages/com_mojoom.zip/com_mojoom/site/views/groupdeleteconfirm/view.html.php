<?php
/** 
 * Group Delete Confirm View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */

class MojoomViewGroupdeleteconfirm extends JView
{
	function display($tpl = null)
	{
		//$my = JFactory::getUser();
		$model = & JModel::getInstance('pgroup','MojoomModel');
		$groupid = JRequest::getVar('group_id',0);
		$group = $model->getGroup($groupid);

		$this->assignRef( 'group',	$group );
		$this->assignRef( 'params',	$params); 
		parent::display($tpl);
	}
	
}