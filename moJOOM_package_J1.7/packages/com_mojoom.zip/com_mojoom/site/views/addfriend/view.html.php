<?php
/** 
 * Add friend View for Mojoom Component
 * 
 * @package   Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 * @package		Mojoom
 * @subpackage	Components
 */
 
class MojoomViewAddfriend extends JView
{
	function display($tpl = null)
	{
		$user_id = JRequest::getVar('user_id',0);
		require_once(JPATH_SITE.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php');
		
		 $my 			= CFactory::getUser();
		 $user  			= CFactory::getUser($user_id);
		 
		 $model = & JModel::getInstance('friend','MojoomModel');
		 $connection		= $model->getFriendConnection( $my->id , $user_id );
		 
		$errflag = '';
		
		if(count( $connection ) > 0 )
		{
			if( $connection[0]->connect_from == $my->id )
			{
				$errflag = "You have already requested to add the user <strong>".$user->getDisplayName()."</strong> as a friend.";
			}
			else
			{
				$errflag = "<strong>". $user->getDisplayName()."%1$s</strong> has already requested to add you as a friend.Please check your pending approval requests.";
			}
		}
		$this->assignRef( 'user_id',	$user_id);
		$this->assignRef( 'user',	$user);
		$this->assignRef( 'errflag',	$errflag);
		
		parent::display($tpl);
	}
	
}