<?php
/**
 * Inbox View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewInbox extends JView
{
	function display($tpl = null)
	{
		$model = $this->getModel();
		$my	=& JFactory::getUser();	
		$msg =& $this->get( 'inbox' );
		// Add small avatar to each image
		if (! empty ( $msg ))
		{
			foreach ( $msg as $key => $val )
			{
				// based on the grouped message parent. check the unread message
				// count for this user.
				$filter ['parent'] = $val->parent;
				$filter ['user_id'] = $my->id;
				
				$unRead = $model->countUnRead( $filter );

				$msg [$key]->unRead = $unRead;
			}
		}
		
		
		if(empty($msg))
		{
		?>
        	<div id="header_text">
				<div id="back"><input type="button" value="Back" class="back" onclick="javascript:history.back();" /></div>
                <div id="header_title">Inbox</div>
                <div id="forward"></div>
	        </div>
			<div class="column body">
				<div class="community-empty-list"><?php echo JText::_('You currently do not have any messages.'); ?></div>
			</div>		   
		<?php 
		}
		else  
		{
			$this->assignRef( 'messages',	$msg );
			parent::display($tpl);
		}
		
	}
}

