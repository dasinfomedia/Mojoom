<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ini_set("display_errors","0"); ?>
<?php
$data = JRequest::get( 'post' );
$user =& JFactory::getUser();
if($user->guest) 
{
?>
	<script>window.location.href="index.php?option=com_mojoom&view=mojoom_login&layout=form";</script>
<?php 
} 
else
{
	$document = JFactory::getDocument();
	$document->setTitle('Profile:Gallery');
?>
<link href="./components/com_mojoom/css/mojoom.css" rel="stylesheet" type="text/css" />
<div id="header_text">
    <div id="back"><!--<input type="button" onclick="javascript:history.back();" class="back" value="Back">-->
    <a href="<?php echo $_SERVER['HTTP_REFERER'];?>" /><input type="button" value="Back" class="back"  /></a></div>
    <div id="header_title">Gallery</div>
</div>
<div class="componentcontent">
	<div id="photos"><span><a href="index.php?option=com_mojoom&view=albums&user_id=<?php echo $user->id; ?>">Photos</a></span></div>
	<div id="videos"><span><a href="index.php?option=com_mojoom&view=videos">Videos</a></span></div>
</div>
<?php 
} 
?>
