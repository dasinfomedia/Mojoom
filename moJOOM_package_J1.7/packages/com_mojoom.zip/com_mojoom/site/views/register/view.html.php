<?php
/**
 * Ragister View for Mojoom Component
 * 
 * @package   Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */
jimport( 'joomla.application.component.view');
/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewRegister extends JView 
{
	function display($tpl = null)
	{
		parent::display($tpl);
	}
}

