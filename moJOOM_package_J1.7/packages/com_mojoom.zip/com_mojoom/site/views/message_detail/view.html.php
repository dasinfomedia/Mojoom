<?php
/**
 * Message Detail View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewMessage_detail extends JView
{
	function display($tpl = null)
	{
		$mainframe =& JFactory::getApplication();
		$model = & JModel::getInstance('message','MojoomModel');
		$msgId = JRequest::getVar ( 'id', '', 'REQUEST' );
		$task = JRequest::getVar ( 'task', '', 'REQUEST' );
		$my = & JFactory::getUser ();
		
		$filter = array ();
		
		$filter ['msgId'] = $msgId;
		$filter ['to'] = $my->id;
		if($task == 'inbox')
		{
			$filter ['parent'] = $msgId;
			$filter ['user_id'] = $my->id;
			$read = $model->markAsRead($filter);	
		}
		$detail = $model->getMessages($filter);
		$this->assignRef( 'Detail',	$detail );
		parent::display($tpl);
	}
}

