<?php
/** 
 * Group Leave Confirm View for mojoom Component
 * 
 * @package    mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the mojoom Component
 *
 * @package		mojoom
 * @subpackage	Components
 */

class MojoomViewGroupleaveconfirm extends JView
{
	function display($tpl = null)
	{
		$model = & JModel::getInstance('pgroup','MojoomModel');
		$groupid = JRequest::getVar('group_id',0);
		$group = $model->getGroup($groupid);

		$this->assignRef( 'group',	$group );
		parent::display($tpl);
	}
	
}