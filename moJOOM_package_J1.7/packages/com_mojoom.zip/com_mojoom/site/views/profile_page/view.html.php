<?php
/**
 * Profile Page View for Mojoom Component
 * 
 * @package   Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewProfile_page extends JView
{
	function display($tpl = null)
	{
		$profile = $this->get( 'Profile' );
		$notification = $this->get( 'Notification' );
		
		$this->assignRef( 'profile',	$profile );
		$this->assignRef( 'Notification',	$notification );
		
		parent::display($tpl);
	}
}

