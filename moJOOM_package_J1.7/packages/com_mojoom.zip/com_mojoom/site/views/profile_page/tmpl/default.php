<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ini_set("display_errors","0"); ?>
<script language="javascript" type="text/javascript">
</script>
<?php
$user =& JFactory::getUser();
if ($user->guest) 
{
	?>
<script type="text/javascript" language="javascript"></script>
Please Login<a href="#/mojoom/index.php?option=com_mojoom&view=mojoom_login&layout=form"> Here </a> 

<?php 
} 
else
{
?>Profile Detail Page
 	<div id="profile_head" style="width:100%; float:left;">
		<div id="profile_action" style="width:100%; float:left;"><a href="index.php?option=com_mojoom&view=profile_edit&layout=form">Edit</a></div>
		<div id="profile_detail" style="width:100%; float:left;">
			<div id="profile_image" style="width:50%; float:left">
				<img src="<?php echo $this->profile->avatar; ?>" width="50px" height="50px" alt="Image Not Available" />
			</div>
			<div id="profile_overview" style="width:50%; float:left;">
				<?php echo  $this->profile->username; ?>			
			</div>
            <div id="profile_notification" style="width:50%; float:left;">
				<?php echo  count($this->Notification); ?>			
			</div>
			<div id="profile_menu" style="width:100%; float:left;">
				<ul style="list-style:square;">
					<li><a href="#/mojoom/index.php?option=com_mojoom&view=profile_detail">View Detail</a></li>
					<li>Messages</li>
					<li>Gallery</li>
				</ul>
			</div>
		</div>
	</div>
	
<?php 
} 
?>
	