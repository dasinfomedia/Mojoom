<?php
/**
 * Profile Detail View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewProfile_detail extends JView
{
	function display($tpl = null)
	{
		$profile = $this->get( 'Profile' );
		//$isNew		= ($swimming->id < 1);	
		$this->assignRef( 'profile',	$profile );
		
		parent::display($tpl);
	}
}

