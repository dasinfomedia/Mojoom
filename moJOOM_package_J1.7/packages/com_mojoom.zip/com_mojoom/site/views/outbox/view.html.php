<?php
/**
 * Outbox View for Mojoom Component
 * 
 * @package   Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewOutbox extends JView
{
	function display($tpl = null)
	{
		$model = & JModel::getInstance('message','MojoomModel');
		$mainframe =& JFactory::getApplication();
		
		$sent = $model->getSent();
		//echo '<pre>';
//		print_r($sent);
//		echo '</pre>';
		if(empty($sent))
		{
		?>
        	<div id="header_text">
				<div id="back"><input type="button" value="Back" class="back" onclick="javascript:history.back();" /></div>
                <div id="header_title">outbox</div>
                <div id="forward"></div>
	        </div>
			<div class="column body">
				<div class="community-empty-list"><?php echo JText::_('You currently do not have any messages.'); ?></div>
			</div>		    
		<?php 
		}
		else 
		{
			$this->assignRef( 'sent',	$sent );
			parent::display($tpl);
		}
		
	}
}

