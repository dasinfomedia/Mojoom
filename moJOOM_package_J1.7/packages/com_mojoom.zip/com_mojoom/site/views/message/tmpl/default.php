<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ini_set("display_errors","0"); ?>
<link rel="stylesheet" href="./components/com_mojoom/css/mojoom.css" type="text/css" />
<div id="header_text">
		<div id="back"><input type="button" value="Back" class="back" onclick="javascript:history.back();" />
        <!--<a href="<?php //echo $_SERVER['HTTP_REFERER'];?>" /><input type="button" value="Back" class="back"  /></a>--></div>
        <div id="header_title">messages</div>
        <div id="forward"></div>
</div>
<div class="componentcontent">
    <div id="inbox">
    	<span><a href="index.php?option=com_mojoom&view=inbox&layout=default">Inbox</a></span>
    </div>
    <div id="outbox">
    	<span><a href="index.php?option=com_mojoom&view=outbox&layout=default">Outbox</a></span>
    </div>
    <div id="compose">
    	<span><a href="index.php?option=com_mojoom&view=compose&layout=default">Compose</a></span>
    </div>
</div>
	