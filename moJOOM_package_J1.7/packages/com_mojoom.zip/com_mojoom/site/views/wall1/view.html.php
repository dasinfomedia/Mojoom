<?php 
/** 
 * Wall1 View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');
/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
 

class MojoomViewWall1 extends JView
{
	function display($tpl = null)
	{
		$model	= $this->getModel();
		$user = JFactory::getUser();
		$userActivities	= $model->getHTML('', '', null, 0 , '' , '', true , false );
		$this->assignRef( 'activities',	$userActivities );
		parent::display($tpl);
	}
	
	function getAvatar($id)
	{
		$db = JFactory::getDBO();
		$query = 'SELECT thumb FROM #__community_users WHERE userid='.$id;
		$db->setQuery( $query );
		$result	= $db->loadObject();
		return $result->thumb;
	}
	
}

