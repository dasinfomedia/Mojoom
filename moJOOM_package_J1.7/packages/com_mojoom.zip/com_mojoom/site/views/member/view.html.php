<?php
/**
 * Member View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components

 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewMember extends JView
{
	function display($tpl = null)
	{
		require_once(JPATH_SITE.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php');
		$config 	= CFactory::getConfig();
		$limit = $config->get('frontpageusers');
		$model1 = CFactory::getModel('user');
		
		$latestMembers = $model1->getLatestMember( $limit );
			

		$this->assignRef( 'friend',	$latestMembers );
		
		parent::display($tpl);
	}
}

