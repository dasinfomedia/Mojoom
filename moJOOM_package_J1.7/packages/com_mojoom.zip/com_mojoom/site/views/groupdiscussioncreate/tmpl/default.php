<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ini_set("display_errors","0"); ?>
<?php
$data = JRequest::get( 'post' );
$user =& JFactory::getUser();
if($user->guest) 
{
?>
	<script>window.location.href="index.php?option=com_mojoom&view=mojoom_login&layout=form";</script>
<?php 
} 
else
{
	$document = JFactory::getDocument();
	$document->setTitle('Group::Add Discussion');
	
?>

<link href="./components/com_mojoom/css/mojoom.css" rel="stylesheet" type="text/css" />
<form method="post" action="index.php" id="creatediscussion" name="jsform-groups-discussion" class="community-form-validate">
<div id="header_text">
	<div id="back"><input type="button" onclick="javascript:history.back();" class="back" value="Back"></div>
	  <div id="header_title_groups">
			<ul id="sub_menu">
				<li class="leftrndcrnr active"><span>&nbsp;</span></li>
				<li id="left"><a href="index.php?option=com_mojoom&controller=groups&task=mygroups" class="active">Groups</a></li><li class="saperator"></li>
				<li id="mid"><a href="index.php?option=com_mojoom&controller=groups&task=myinvite">MyInvites</a></li>
				<li class="saperator"></li>
				<li id="right"><a href="index.php?option=com_mojoom&controller=groups&task=create">Create</a></li>
				<li class="rightrndcrnr"></li>
			</ul>
	</div>
	<div id="forward" class="android"><input type="submit" class="edit" value="Add" /></div>   
</div>
<div class="componentcontent">
	<div class="groupsdisscussioncontainer">
<!--==========================================	 -->
<table class="formtable">
	<?php echo $beforeFormDisplay;?>
	<?php if ( $this->config->get( 'htmleditor' ) == 'jce' ) : ?>
	<tr class="fromrow">
		<td class="key" >
			<label for="title" class="label" style="text-align: left;">*<?php echo JText::_('Discussion Title'); ?></label>
		</td>
	</tr>
	<tr class="fromrow">
		<td class="value" >
			<input type="text" name="title" id="title" class="inputbox" value="" style="width:100%;float:left;" />
		</td>
	</tr>
	
	<tr class="fromrow">
		<td class="key" >
			<label for="message" class="label" style="text-align: left;">*<?php echo JText::_('Discussion Message'); ?></label>
		</td>
	</tr>
	<tr class="fromrow">
		<td class="value" >
			<?php if( $this->config->get( 'htmleditor' ) && $this->config->getBool( 'allowhtml' ) ) : ?>
				<?php echo $this->editor->display( 'message',  '' , '95%', '200', '10', '20' , false ); ?>
			<?php else : ?>
				<textarea rows="3" cols="40" name="message" id="message" class="inputbox" style="width:100%;float:left;height:120px"></textarea>
			<?php endif; ?>
		</td>
	</tr>
	
	<?php else : ?>
	
	<tr class="fromrow">
		<td class="key">
			<label for="title" class="label">*<?php echo JText::_('Discussion Title'); ?></label>
		</td>
	</tr>
	<tr class="fromrow">
		<td class="value">
			<input type="text" name="title" id="title"  class="inputbox" value="" style="width:100%;float:left;" />
		</td>
	</tr>
	
	<tr class="fromrow">
		<td class="key">
			<label for="message" class="label">*<?php echo JText::_('Discussion Message'); ?></label>
		</td>
	</tr>
	<tr class="fromrow">
		<td class="value"> 
			<textarea rows="3" cols="40" name="message" id="message" class="inputbox" style="width:100%;float:left;height:120px"></textarea>
			

		</td>
	</tr>
	
	<?php endif; ?>
	
	<tr class="fromrow">
		<td class="key"></td>
		<td class="value">
			<span class="hints"><?php echo JText::_( 'Fields marked with an asterisk (*) are required.' ); ?></span>
		</td>
	</tr>
	<tr class="fromrow">
		<td class="key"></td>
		<td class="value">
			<input type="hidden" value="<?php echo $this->group->id; ?>" name="group_id" />
			
		</td>
	</tr>
</table>
<input type="hidden" name="option" value="com_mojoom" />
<input type="hidden" name="task" value="savedisscussion" />
<input type="hidden" name="controller" value="groups" />

</form>
<!--========================================== -->
</div>
</div>
<?php
}
?>