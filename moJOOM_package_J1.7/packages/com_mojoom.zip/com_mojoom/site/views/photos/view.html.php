<?php
/**
 * Photos View for Mojoom Component
 * 
 * @package   Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');
jimport( 'joomla.utilities.date');
/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewPhotos extends JView
{
	function display($tpl = null)
	{
		$albumId	= JRequest::getVar('album_id' , '');
		$model	= $this->getModel();
		// 2nd argument for the PHOTOS_USER_TYPE and PHOTOS_GROUP_TYPE but here for individual so it is user
 		$photos	= $model->getAllPhotos( $albumId ,'user',null,'DESC');
		$this->assignRef( 'photos',	$photos );
		parent::display($tpl);
	}
}

