<?php
/**
 * Group Alumb View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the HelloWorld Component
 *
 * @package		Joomla.Tutorials
 * @subpackage	Components
 */
class MojoomViewGroup_albums extends JView
{
	function display($tpl = null)
	{
		$model	= $this->getModel();
		$groupId	= JRequest::getVar('group_id' , '');
		// 2nd argument for the PHOTOS_USER_TYPE and PHOTOS_GROUP_TYPE but here for individual so it is user
 		$group_albums	= $model->getGroup_albums( $user->id ,'group',$groupId);
		$this->assignRef( 'group_albums',	$group_albums );
		parent::display($tpl);
	}
	
	function createdLapse(&$date)
	{
		

		$now	=& JFactory::getDate();

		$html	= '';

		$diff	= $this->_timeDifference($date->toUnix(), $now->toUnix());

		if( !empty($diff['days']) )

		{

			$days		= $diff['days'];

			$months		= ceil( $days / 30 );

			if( $days == 1 )

			{

				

			}

			

			switch( $days )

			{

				case ($days == 1):

				

					// @rule: Something that happened yesterday

					$html	.= JText::_( 'yesterday' );



				break;

				case ( $days > 1 && $days < 7 && $days < 30 ):

				

					// @rule: Something that happened within the past 7 days

					$html	.= JText::sprintf( '%1$s days' , $days ) . ' ';



				break;

				case ( $days > 1 && $days > 7 && $days < 30 ):

				

					// @rule: Something that happened within the month but after a week

					$weeks	= round( $days / 7 );

					$html	.= JText::sprintf( CStringHelper::isPlural( $weeks ) ? '%1$s weeks' : '%1$s week' , $weeks ) . ' ';	



				break;

				case ( $days > 30 && $days < 365 ):

				

					// @rule: Something that happened months ago

					$months	= round( $days / 30 );

					$html	.= JText::sprintf( CStringHelper::isPlural( $months ) ? '%1$s months' : '%1$s month' , $months ) . ' ';



				break;

				case ( $days > 365 ):

				

					// @rule: Something that happened years ago

					$years	= round( $days / 365 );

					$html	.= JText::sprintf( CStringHelper::isPlural( $years ) ? '%1$s years' : '%1$s year' , $years ) . ' ';



				break;

			}

		}

		else

		{

			// We only show he hours if it is less than 1 day

			if(!empty($diff['hours']))				

				$html .= JText::sprintf('%1$s hours', $diff['hours']) . ' ';

			

			if(!empty($diff['minutes']))

				$html .= JText::sprintf('%1$s minutes', $diff['minutes']) . ' ';

		}

		

		if(empty($html)){

			$html .= JText::_('less than a minute ');

		}

		

		if($html != JText::_('yesterday'))

			$html .= JText::_('ago');

		return $html;

	}

	function getusername($id)
	{
		$db = JFactory::getDBO();
		$query = 'SELECT name,username FROM #__users WHERE id='.$id;
		$db->setQuery( $query );
		$result	= $db->loadObject();
		return $result;
	}
	
	function _timeDifference($start , $end )
	{
		jimport('joomla.utilities.date');
	
			if(is_string($start) && ($start != intval($start))){
	
				$start = new JDate($start);
	
				$start = $start->toUnix();
	
			}
		
			if(is_string($end) && ($end != intval($end) )){
	
				$end = new JDate($end);
	
				$end = $end->toUnix();
	
			}
	
			$uts = array();
	
			$uts['start']      =    $start ;
	
			$uts['end']        =    $end ;
	
			if( $uts['start']!==-1 && $uts['end']!==-1 )
	
			{
	
				if( $uts['end'] >= $uts['start'] )
	
				{
	
					$diff    =    $uts['end'] - $uts['start'];
	
					if( $days=intval((floor($diff/86400))) )
	
						$diff = $diff % 86400;
	
					if( $hours=intval((floor($diff/3600))) )
	
						$diff = $diff % 3600;
	
					if( $minutes=intval((floor($diff/60))) )
	
						$diff = $diff % 60;
	
					$diff    =    intval( $diff );            
	
					return( array('days'=>$days, 'hours'=>$hours, 'minutes'=>$minutes, 'seconds'=>$diff) );
	
				}
	
				else
	
				{
	
					trigger_error( JText::_("Ending date/time is earlier than the start date/time"), E_USER_WARNING );
	
				}
	
			}
	
			else
	
			{
	
				trigger_error( JText::_("Invalid date/time data detected"), E_USER_WARNING );
	
			}
	
			return( false );
	
		
		}
}

