<?php
/**
 * Mojoom View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
  * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewMojoom extends JView
{
	function display($tpl = null) 
	{
		$profile = $this->get( 'Profile' );
		$msg = $this->get( 'Notification_msg' );
		$frd = $this->get( 'Notification_frd' );
		$event = $this->get( 'Notification_event' );
		
		$notification = count($msg) + count($frd) + count($event);
		
		$this->assignRef( 'profile',	$profile );
		$this->assignRef( 'Notification',	$notification );
				
		parent::display($tpl);
	}
}