<?php
/**
 * Notification View for Mojoom Component
 * 
 * @package    Mojoom
 * @subpackage Components
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Mojoom Component
 *
 * @package		Mojoom
 * @subpackage	Components
 */
class MojoomViewNotification extends JView
{
	function display($tpl = null)
	{
		$model = & JModel::getInstance('Mojoom','MojoomModel');
		$mainframe =& JFactory::getApplication();
		
		$msg = $model->getNotification_msg();
		$frd = $model->getNotification_frd();
		$event = $model->getNotification_event();
		
		$this->assignRef( 'Notification_msg',	$msg );
		$this->assignRef( 'Notification_frd',	$frd );
		$this->assignRef( 'Notification_event',	$event );
		
		parent::display($tpl);
	}
}

