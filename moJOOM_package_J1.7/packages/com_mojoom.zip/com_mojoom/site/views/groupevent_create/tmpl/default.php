<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ini_set("display_errors","0"); ?>
<?php 
$document = JFactory::getDocument();
if($this->Event->id == ""){
$document->setTitle('Create New Group Event');
}else {
$document->setTitle('Editing Group Event');
}
?>
<link rel="stylesheet" href="./components/com_mojoom/css/mojoom.css" type="text/css" />
<script type="text/javascript">
function validate()
{
	if(document.getElementById('title').value == "")
	{
		alert('Title info is required. Make sure it contains a valid value!');
		return false;	
	}
	if(document.getElementById('location').value == "")
	{
		alert('Location info is required. Make sure it contains a valid value!');
		return false;	
	}
	if(document.getElementById('startdate').value == "")
	{
		alert('Startdate info is required. Make sure it contains a valid value!');
		return false;	
	}
	if(document.getElementById('enddate').value == "")
	{
		alert('Enddate info is required. Make sure it contains a valid value!');
		return false;	
	}
	if(document.getElementById('ticket').value == "")
	{
		alert('No. of seats info is required. Make sure it contains a valid value!');
		return false;	
	}
}
</script>

<form id="form1" method="post" action="index.php" enctype="multipart/form-data" >
<div id="header_text">
    <div id="back"><input type="button" onclick="javascript:history.back();" class="back" value="Back"></div>
    <div id="header_title_events">
            <ul id="sub_menu">
            	<li class="leftrndcrnr active"></li>
                <li id="left"><a href="index.php?option=com_mojoom&controller=event&task=myevents" >Events</a></li>
                <!--<li class="saperator"></li>
                <li id="mid"><a href="index.php?option=com_mojoom&controller=event&task=invite">Category</a></li>-->
                <li class="saperator"></li>
                <li id="right"><a href="index.php?option=com_mojoom&controller=event&task=create" class="active">Create</a></li>    
                <li class="rightrndcrnr ractive"><span>&nbsp;</span></li>                 
            </ul>
    </div>
    <div id="forward" class="android"><input type="submit" name="submit" id="submit" value="Save" class="edit" onclick="return validate();" /></div>
</div>
<div class="componentcontent"> 
	<?php if($this->Event_Count < $this->eventcreatelimit) { ?>
    <div class="detail">
	    <?php if($this->eventcreatelimit != 0 ) { ?>
    		<span><?php echo JText::sprintf('You have created <strong>%1$s</strong> out of <strong>%2$s</strong> allowed event creation.', $this->Event_Count, $this->eventcreatelimit );?></span>
        <?php } ?>    	 
		    <div class="detail_1">
			<label for="gender">Title</label>				 	
            	<input type="text" name="title" id="title" value="<?php echo $this->Event->title; ?>" />                
		 	</div>
            <div class="detail_border"></div>
            
            <div class="detail_1">
			<label for="gender">Description</label>				 	
            	<textarea name="description" id="description" ><?php echo strip_tags($this->Event->description); ?></textarea>
		 	</div>
            <div class="detail_border"></div>           
            
            <div class="detail_1">
			<label for="gender">Category</label>				 	
            	 <select name="catid" id="catid" >
				<?php foreach( $this->Category as $category ){ ?>
					<option value="<?php echo $category->id;?>" <?php if($this->Event->catid == $category->id) { ?> selected="selected" <?php } ?> ><?php echo $category->name; ?></option>
				<?php } ?>
				</select>                   
		 	</div>
            <div class="detail_border"></div>
            
            <div class="detail_1">
			<label for="gender">Location</label>				 	
            	<input type="text" name="location" id="location" value="<?php echo $this->Event->location; ?>" />                
		 	</div>
            <div class="detail_border"></div>
            
            <div class="detail_1">
                <label for="b_date" id="b_dateLabel" name="b_dateLabel">Start Date</label>		
                <?php
				$date_time = explode(' ',$this->Event->startdate); 				
				$time = explode(':',$date_time[1]);
				if($time[0] > 12 )				
				{
					$s_hour	= $time[0] - 12;
					$s_ampm = 'PM'; 	 
				}
				else
				{
					$s_hour = $time[0];
					$s_ampm = 'AM'; 	 
				}				
				$s_min = $time[1];
				
				?>
                <?php echo $this->createMonths1; ?> 
				<?php echo $this->createDays1; ?>
				<?php echo $this->createYears1; ?><br />                
                <select class="required inputbox" id="starttime-hour" name="starttime-hour">
                	<?php for($i=1;$i<=12;$i++) { ?>
                    <option value="<?php echo $i; ?>" <?php if($i == $s_hour) { ?> selected="selected" <?php } ?>><?php echo $i; ?></option>
                    <?php } ?>                   
                 </select>
                 :
                 <select class="required inputbox" id="starttime-min" name="starttime-min">
                 	<?php for($i=0;$i<45;$i=$i+15) { ?>
                    <option value="<?php echo $i; ?>" <?php  if($i == $s_min) { ?> selected="selected" <?php }?> > 
						<?php echo $i; ?> 
                    </option> 
                    <?php } ?>                    
                 </select> 
                 <select class="required inputbox" id="starttime-ampm" name="starttime-ampm">
                 	<option value="AM" <?php if($s_ampm == 'AM'){ ?> selected="selected" <?php } ?>  >am</option>
                    <option value="PM" <?php if($s_ampm == 'PM'){ ?> selected="selected" <?php } ?>>pm</option>
                 </select>
             </div>
             <div class="detail_border"></div>
            
            <div class="detail_1">
                <label for="b_date" id="b_dateLabel" name="b_dateLabel">End Date</label>
                <?php 
				$date_time = explode(' ',$this->Event->enddate); 				
				$time = explode(':',$date_time[1]);
				if($time[0] > 12 )				
				{
					$e_hour	= $time[0] - 12;
					$e_ampm = 'PM'; 	 
				}
				else
				{
					$e_hour = $time[0];
					$e_ampm = 'AM'; 	 
				}				
				$e_min = $time[1];
				?>	
                <?php echo $this->createMonths2; ?> 
				<?php echo $this->createDays2; ?>
				<?php echo $this->createYears2; ?><br />	
                <select class="required inputbox" id="endtime-hour" name="endtime-hour">
                	<?php for($i=1;$i<=12;$i++) { ?>
                    <option value="<?php echo $i; ?>"  <?php if($i == $e_hour) { ?> selected="selected" <?php } elseif($i==4) { ?> selected="selected" <?php }else{} ?> ><?php echo $i; ?> </option>
                    <?php } ?>                   
                </select>
                :
                <select class="required inputbox" id="endtime-min" name="endtime-min">
                	<?php for($i=0;$i<45;$i=$i+15) { ?>
                    <option value="<?php echo $i; ?>"  <?php if($i == $e_min) { ?> selected="selected" <?php } ?> > <?php echo $i; ?> </option>
                    <?php } ?>   
                </select> 
                <select class="required inputbox" id="endtime-ampm" name="endtime-ampm">
                   <option value="AM" <?php if($e_ampm == 'AM'){ ?> selected="selected" <?php } ?>  >am</option>
                    <option value="PM" <?php if($e_ampm == 'PM'){ ?> selected="selected" <?php } ?> >pm</option>
                </select>			
            </div>
            <div class="detail_border"></div>                         
           	<div class="detail_1">
			<label for="gender">Timezone</label>				 	            	
               <select name="offset" style="width:125px;">
				<?php
				foreach( $this->Timezone as $offset => $value ){
				?>
					<option value="<?php echo $offset;?>" <?php if($offset == $this->Event->offset){ ?>  selected="selected" <?php }elseif($offset == 0){?> selected="selected" <?php }else {} ?> > <?php echo $value;?> </option>
				<?php
				}
				?>
				</select>              
		 	</div>
            <div class="detail_border"></div>
            
            <div class="detail_1">
			<label for="gender">Type</label>				 	
            	<div style="float:left; width:50%;">
                <input type="radio" name="permission" id="permission-open" value="0" <?php if($this->Event->permission == 0 ) { ?> checked="checked" <?php } ?> />Open
                <!--<span style="width:60%; float:left;">All site members can join your event and RSVP.</span>-->
                </div>
                <div style="float:left; width:50%;">
                <input type="radio" name="permission" id="permission-private" value="1" <?php if($this->Event->permission == 1 ) { ?> checked="checked" <?php } ?>  />Private
               <!-- <span style="width:60%; float:left;">Only invited people can RSVP. Others will be able to request an invitation.</span><br />-->
				</div>                
		 	</div>            
            <div class="detail_border"></div>
            
            <div class="detail_1">
			<label for="gender">No. of seats</label>				 	
            	<input type="text" name="ticket" id="ticket" value="<?php echo $this->Event->ticket; ?>" />                
		 	</div>
            <div class="detail_border"></div>
            
            <div class="detail_1">
			<label for="gender">Allow guest to invite</label>
            	<div style="float:left; width:50%;">				 	
            	<input type="radio" name="allowinvite" id="allowinvite0" value="1" <?php if($this->Event->allowinvite == 1 ) { ?> checked="checked" <?php } ?>  />Yes
                <!--<span>Allow guests to invite their friends.</span>-->
                </div>
                <div style="float:left; width:50%;">
                <input type="radio" name="allowinvite" id="allowinvite1" value="0" <?php if($this->Event->allowinvite == 0 ) { ?> checked="checked" <?php } ?>  />No
                <!--<span>Disallow guests to invite their friends.</span>-->
                </div>                
		 	</div>            
     </div>     	
	<?php } else { ?>
	<div class="detail">
    <span><?php echo 'you are already created maximum event.';?></span>
	<?php } ?> 
     
</div>
	<input type="hidden" name="option" value="com_mojoom" />
	<input type="hidden" name="task" value="save_groupevent" />
	<input type="hidden" name="controller" value="event" />
	<input type="hidden" name="id" value="<?php echo $this->Event->id; ?>" />
    <input type="hidden" name="contentid" value="<?php echo $this->group_id; ?>" />
	</form>		


