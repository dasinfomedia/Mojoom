<?php
/**
 * MoJoom - moJOOM is easily mobilized your social-networking
 * site which is developed using JomSocial , displaying perfect 
 * in iphone , Android and blackberry and all other Phones.
 * Copyright (C) 2003 - 2011, Dasinfomedia Pvt Ltd
 *
 * All rights reserved.  The MoJoom is a set of extentions for
 * the content management system Joomla!. It enables Joomla!
 * This program is paid software; 
 *
 * The "GNU General Public License" (GPL) is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * -----------------------------------------------------------------------------
 * @version		1.0.0
 * @package		Mojoom
 * @copyright	2003 - 2011, Dasinfomedia Pvt Ltd
 * @license		Open Source License, GPL v2 based
 * 
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Check to see if a plugin by the same name is already installed
// get the mojoom component's id
$query = 'SELECT `id` FROM `#__extensions` WHERE name= "'.$db->Quote('mojoom').'" ';
$db->setQuery($query);
$componentID = $db->loadResult();

// get the jomsocial component's id
$query1 = "SELECT `id` FROM `#__extensions` WHERE link='".$db->Quote('option=com_community')."'";
$db->setQuery($query1);
$componentID1 = $db->loadResult();
$rows = 0;

// installation of the menu
// insert it in the jos_menu_types
$obj = new stdClass();
$obj->id = '';
$obj->menutype = 'mojoommenu';
$obj->title = 'moJoomMenu';
$obj->description = 'Menu creted by Mojoom';
$db->insertObject('#__menu_types', $obj, 'id');
$menuid = $obj->id;

// create 1st menu item
$obj3 = new stdClass();
$obj3->id = "";
$obj3->menutype = "mojoommenu";
$obj3->title = "Home";
$obj3->alias = "mojoomhome";
$obj3->note = "";
$obj3->path = "mojoomhome";
$obj3->link = "index.php?option=com_content&view=article&id='68'&Itemid=73";
$obj3->type = "component";
$obj3->published = 1;
$obj3->parent_id = 1;
$obj3->level = 1;
$obj3->component_id = 22;
$obj3->ordering = 1;
$obj3->checked_out = 0;
$obj3->checked_out_time = "0000-00-00 00:00:00";
$obj3->browserNav = 0;
$obj3->access = 1;
$obj3->img = "";
$obj3->params = '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}'; 
$obj3->lft = 0;
$obj3->rgt = 0;
$obj3->home = 0;
$obj3->language = "";
$obj3->client_id = 0;
$db->insertObject('#__menu', $obj3, 'id');

//step 5 : create 2nd menu item
$obj4 = new stdClass();
$obj4->id = '';
$obj4->menutype = 'mojoommenu';
$obj4->title = 'Profile';
$obj4->alias = 'mojoomprofile';
$obj4->note = "";
$obj4->path = "mojoomprofile";
$obj4->link = "index.php?option=com_mojoom&view=mojoom";
$obj4->type = "component";
$obj4->published = 1;
$obj4->parent_id = 1;
$obj4->level = 1;
$obj4->component_id = $componentID;
$obj4->ordering = 2; 
$obj4->checked_out = 0;
$obj4->checked_out_time = "0000-00-00 00:00:00";
$obj4->browserNav = 0;
$obj4->access = 1;
$obj4->img = "";
$obj4->params = '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}';
$obj4->lft = 0;
$obj4->rgt = 0;
$obj4->home = 0;
$obj4->language = "";
$obj4->client_id = 0;
$db->insertObject('#__menu', $obj4, 'id');
//step 6 : create 3rd menu item
$obj5 = new stdClass();
$obj5->id = '';
$obj5->menutype = 'mojoommenu';
$obj5->title = 'About us';
$obj5->alias = 'mojoomaboutus';
$obj5->note = "";
$obj5->path = "mojoomaboutus";
$obj5->link = "index.php?option=com_content&view=article&id=68&Itemid=73";
$obj5->type = "component";
$obj5->published = 1;
$obj5->parent_id = 1;
$obj5->level = 1;
$obj5->component_id = 22;
$obj5->ordering = 3; 
$obj5->checked_out = 0;
$obj5->checked_out_time = '0000-00-00 00:00:00';
$obj5->browserNav = 0;
$obj5->access = 1;
$obj5->img = "";
$obj5->params ='{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}';
$obj5->lft = 0;
$obj5->rgt = 0;
$obj5->home = 0;
$obj5->language = "";
$obj5->client_id = 0;
$db->insertObject('#__menu', $obj5, 'id');
//step 7 : create 4th menu item
$obj6 = new stdClass();
$obj6->id = '';
$obj6->menutype = 'mojoommenu';
$obj6->title = 'More';
$obj6->alias = 'mojoommore';
$obj6->note = "";
$obj6->path = "mojoommore";
$obj6->link = "index.php?option=com_content&view=article&id=68&Itemid=73";
$obj6->type = "component";
$obj6->published = 1;
$obj6->parent_id = 1;
$obj6->level = 1;
$obj6->component_id = 22;
$obj6->ordering = 4; 
$obj6->checked_out = 0;
$obj6->checked_out_time = '0000-00-00 00:00:00';
$obj6->browserNav = 0;
$obj6->access = 1;
$obj6->img = "";
$obj6->params =  '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}'; 
$obj6->lft = 0;
$obj6->rgt = 0;
$obj6->home = 0;
$obj6->language = "";
$obj6->client_id = 0;
$db->insertObject('#__menu', $obj6, 'id');
// insert into the jos_modules
$obj1 = new stdClass();
$obj1->id = "";
$obj1->title = "moJoomMenu";
$obj1->note = "";
$obj1->content = "";
$obj1->ordering = 1;
$obj1->position = "mojoom";
$obj1->checked_out = 0;
$obj1->checked_out_time = "0000-00-00 00:00:00";
$obj1->publish_up = "0000-00-00 00:00:00";
$obj1->publish_down = "0000-00-00 00:00:00";
$obj1->published = 1;
$obj1->module = "mod_menu";
$obj1->access = 1;
$obj1->showtitle = 1;
$obj1->params = '{"menutype":"mojoommenu","startLevel":"1" ,"endLevel":"0", "showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}';
$obj1->client_id = 0;
$obj1->language = "*";
$db->insertObject('#__modules', $obj1, 'id');
$moduleid = $obj1->id;
//insert into the jos_modules_menu 
$obj2 = new stdClass();
$obj2->moduleid = $moduleid;
$obj2->menuid = 0;
$db->insertObject('#__modules_menu', $obj2, 'id');

?>
<?php 
	// install templates
	$TemplateSource = JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_mojoom'.DS.'template';
	$templates = array ('mojoom');
	$status1 = true;
	foreach($templates as $template)
	{
		if(!InstallTemplate($TemplateSource.DS.$template, $template))
		{
			$status1 = false;
			$ERRORS[] = "<b>".JText::_('Cannot install:')." MoJoom '$template' template.</b>";
		}
	}
	
	if($status1)
		JFolder::delete($TemplateSource);

function InstallTemplate($sourcedir, $name)
{
	global $ERRORS;
	$TemplateDir = JPATH_ROOT.DS.'templates'.DS.$name;
	if(!is_dir($sourcedir))
	{
		$ERRORS[] = JText::_('Cannot find directory:')." $sourcedir.";
		return false;
	}
	if(is_dir($TemplateDir) && !JFolder::delete($TemplateDir))
	{
		$ERRORS[] = JText::_('Cannot remove directory:').' '.$TemplateDir;
		return false;
	}
	$status1 = true===JFolder::move($sourcedir, $TemplateDir);
	if(is_file($TemplateDir.DS.'templateDetails.xm_') &&
			!JFile::move($TemplateDir.DS.'templateDetails.xm_', $TemplateDir.DS.'templateDetails.xml'))
	{
		$ERRORS[] = str_replace(array ('%1', '%2'),
		                        array ($TemplateDir.DS.'templateDetails.xm_', $TemplateDir.DS.'templateDetails.xml'),
		                        JText::_("Cannot rename '%1' into '%2'."));
		$status1 = false;
	}
	else
	{
		/** @var JDatabase $db */
		$db =& JFactory::getDBO();
		$query = 'SELECT COUNT(*) FROM #__template_styles WHERE template = '.$db->Quote($name);
		$db->setQuery($query);
		if($db->loadResult()==0)
		{
			$query = 'INSERT INTO #__template_styles (id,template,client_id,home,title,params) VALUES ("",'.$db->Quote($name).',0,-1,"Mojoom-Default","{}")';
			$db->setQuery($query);
			$db->query();
			
			$query1 = 'INSERT INTO #__extensions (extension_id,name,type,element,folder,client_id,enabled,access,protected,manifest_cache, params, custom_data, system_data, checked_out, checked_out_time, ordering, state ) VALUES ("","Mojoom","template","mojoom","",0,1,1,0,"{}","{}","","",0,"",0,0)';
			$db->setQuery($query1);
			$db->query();
		}
	}
	return $status1;
}
?>
<img src="../components/com_mojoom/images/logo.png" width="88" height="33" alt="Mojoom ! Mobile based social networking " align="right" />

<h2>Mojoom Installation</h2>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th width="30%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'Mojoom '.JText::_('Component'); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
<?php
if (count($status->templates)) : ?>
		<tr>
			<th colspan="2"><?php echo JText::_('Template'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->templates as $template) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($template['name']); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif; ?>
<?php
if (count($status->plugins)) : ?>
		<tr>
			<th><?php echo JText::_('Plugin'); ?></th>
			<th><?php echo JText::_('Group'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->plugins as $plugin) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
			<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
			<td><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif; ?>
	</tbody>
</table>
