<?php
/**
 * MoJoom - moJOOM is easily mobilized your social-networking
 * site which is developed using JomSocial , displaying perfect 
 * in iphone , Android and blackberry and all other Phones.
 * Copyright (C) 2003 - 2011, Dasinfomedia Pvt Ltd
 *
 * All rights reserved.  The MoJoom is a set of extentions for
 * the content management system Joomla!. It enables Joomla!
 * This program is paid software; 
 *
 * The "GNU General Public License" (GPL) is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * -----------------------------------------------------------------------------
 * @version		1.0.0
 * @package		Mojoom
 * @copyright	2003 - 2011, Dasinfomedia Pvt Ltd
 * @license		Open Source License, GPL v2 based
 * 
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.helper');
$rows = 0;

///// delete menutype/////////////
$query3 = 'DELETE FROM #__menu_types WHERE menutype = "mojoommenu" ';
$db->setQuery($query3);
$db->query();
///////////////////////////////////////
/////////////module/////////////////////

$query4 = 'SELECT id FROM #__modules WHERE position = "mojoom" ';
$db->setQuery($query4);
$moduleidID = $db->loadResult();

$query5 = 'DELETE FROM #__modules WHERE position = "mojoom" ';
$db->setQuery($query5);
$db->query();

$query6 = 'DELETE FROM #__modules_menu WHERE moduleid = "'.$moduleidID.'" ';
$db->setQuery($query6);
$db->query();

$query7 = 'DELETE FROM #__menu WHERE menutype = "mojoommenu" ';
$db->setQuery($query7);
$db->query();
?>

<h2>Mojoom Uninstallation</h2>
<h3><b style="color:#FF0000">Note</b>:- Uninstall a Template Individually</h3>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th width="30%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'Mojoom'.JText::_('Component'); ?></td>
			<td><strong><?php echo JText::_('Removed'); ?></strong></td>
		</tr>
	</tbody>
</table>
<table class="adminlist">
</table>